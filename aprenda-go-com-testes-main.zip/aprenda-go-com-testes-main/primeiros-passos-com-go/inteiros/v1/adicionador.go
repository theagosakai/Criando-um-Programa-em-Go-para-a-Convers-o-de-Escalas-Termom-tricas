package inteiros

// Adiciona recebe dois inteiros e retorna a soma deles
func Adiciona(x, y int) int {
	return x + y
}
