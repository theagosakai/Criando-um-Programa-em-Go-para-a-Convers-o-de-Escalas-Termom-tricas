package main

import "fmt"

// Ola retorna uma saudação
func Ola() string {
	return "Olá, mundo"
}

func main() {
	fmt.Println(Ola())
}
