# Glossário

Sinta-se livre para colaborar com esse glossário no repositório oficicial.
Organizar termos do glossário em ordem alfabética.
Se possível, procurar pelos termos nos textos já traduzidos e linkar com esse glossário.

## palavra

Explicação.

Encontrado em:
- [capitulo](link-para-o-capitulo.md)

## palavra

Explicação.

Encontrado em:
- [capitulo](link-para-o-capitulo.md)

## palavra

Explicação.

Encontrado em:
- [capitulo](link-para-o-capitulo.md)