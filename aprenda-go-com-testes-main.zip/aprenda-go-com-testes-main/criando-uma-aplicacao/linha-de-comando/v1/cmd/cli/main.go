package main

import "fmt"

func main() {
	fmt.Println("Vamos jogar poquer")
}
